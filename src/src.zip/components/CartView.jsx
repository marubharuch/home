import React, { useEffect, useState } from "react";
import { loadOrder, deleteOrder } from "../utils/orderUtils";

export default function CartView({ orderKey, onSave, onModify }) {
  const [cart, setCart] = useState({});
  const [orderInfo, setOrderInfo] = useState({});

  useEffect(() => {
    const fetchOrder = async () => {
      if (orderKey && orderKey !== "NEW") {
        const order = await loadOrder(orderKey);
        if (order) {
          setCart(order.cart || {});
          setOrderInfo({
            phone: order.mobile,
            serial: order.serial || orderKey.split("/").pop(),
            createdAt: order.createdAt || order.updatedAt,
          });
        }
      }
    };
    fetchOrder();
  }, [orderKey]);

  const handleQtyChange = (itemKey, qty) => {
    setCart((prev) => ({
      ...prev,
      [itemKey]: { ...prev[itemKey], quantity: parseFloat(qty) || 0 },
    }));
  };

  const handleDeleteItem = (itemKey) => {
    setCart((prev) => {
      const updated = { ...prev };
      delete updated[itemKey];
      return updated;
    });
  };

  const handleDeleteOrder = async () => {
    if (window.confirm("Delete entire order?")) {
      await deleteOrder(orderKey);
      onModify(); // go back
    }
  };

  const total = Object.values(cart).reduce(
    (sum, item) =>
      sum + (parseFloat(item.finalPrice) || 0) * (item.quantity || 0),
    0
  );

  return (
    <div className="p-4 bg-white shadow rounded">
      {orderKey !== "NEW" && (
        <div className="mb-3 text-sm text-gray-600">
          <p>📞 Phone: {orderInfo.phone}</p>
          <p>🆔 Order No: {orderInfo.serial}</p>
          <p>📅 Date: {orderInfo.createdAt}</p>
        </div>
      )}

      <div className="space-y-2">
        {Object.entries(cart).map(([key, item]) => (
          <div
            key={key}
            className="flex justify-between items-center border p-2 rounded"
          >
            <div>
              <p className="font-medium">{item.name}</p>
              <p className="text-xs text-gray-500">₹{item.finalPrice}</p>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={item.quantity || ""}
                onChange={(e) => handleQtyChange(key, e.target.value)}
                className="border w-16 text-center rounded"
              />
              <button
                onClick={() => handleDeleteItem(key)}
                className="bg-red-500 text-white px-2 py-1 rounded"
              >
                🗑️
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex justify-between items-center">
        <p className="text-lg font-semibold">Total: ₹{total.toFixed(2)}</p>
        <div className="flex gap-2">
          <button
            onClick={() => onSave(cart)}
            className="bg-green-600 text-white px-3 py-1 rounded"
          >
            💾 Save
          </button>
          {orderKey !== "NEW" && (
            <button
              onClick={handleDeleteOrder}
              className="bg-red-600 text-white px-3 py-1 rounded"
            >
              Delete Order
            </button>
          )}
          <button
            onClick={onModify}
            className="bg-gray-400 text-white px-3 py-1 rounded"
          >
            Back
          </button>
        </div>
      </div>
    </div>
  );
}
