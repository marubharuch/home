import localforage from "localforage";

// ✅ Load a specific order
export async function loadOrder(orderKey) {
  const allOrders = (await localforage.getItem("orders")) || {};
  return allOrders[orderKey] || null;
}

// ✅ Delete an order
export async function deleteOrder(orderKey) {
  const allOrders = (await localforage.getItem("orders")) || {};
  delete allOrders[orderKey];
  await localforage.setItem("orders", allOrders);
}

// ✅ Save or merge order
export async function saveOrder(mobileInput, newItems) {
  const allOrders = (await localforage.getItem("orders")) || {};
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");

  const match = mobileInput.match(/^(\d{10})(?:\/(new|\d+))?$/);
  if (!match) throw new Error("Invalid mobile input");

  const [, mobile, orderPart] = match;
  let orderKey;

  if (orderPart && orderPart !== "new") {
    // Merge with existing order
    orderKey = `${mobile}/${year}/${month}/${orderPart}`;
    const existing = allOrders[orderKey]?.cart || {};
    allOrders[orderKey] = {
      ...allOrders[orderKey],
      cart: { ...existing, ...newItems },
      updatedAt: now.toLocaleString(),
    };
  } else {
    // New order
    const userOrders = Object.keys(allOrders).filter((k) =>
      k.startsWith(`${mobile}/${year}/${month}`)
    );
    const nextSerial = userOrders.length + 1;
    orderKey = `${mobile}/${year}/${month}/${nextSerial}`;
    allOrders[orderKey] = {
      cart: newItems,
      mobile,
      createdAt: now.toLocaleString(),
      serial: nextSerial,
    };
  }

  await localforage.setItem("orders", allOrders);

  const total = Object.values(allOrders[orderKey].cart).reduce(
    (sum, item) =>
      sum + (parseFloat(item.finalPrice) || 0) * (item.quantity || 0),
    0
  );

  return { orderKey, total, mobile };
}
