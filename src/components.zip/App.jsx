// src/App.jsx (updated)
import React, { useEffect, useState, lazy, Suspense } from "react";
import { loadAndCacheAllJson } from "./utils/jsonLoader";
import {
  getCartCount,
  getAllOrders,
  sortOrdersByDate,
  calculateTotal,
  clearCart
} from "./utils/orderUtils";

import OrderPopup from "./components/OrderPopup";
import MobilePopup from "./components/MobilePopup";

const SearchBar = lazy(() => import("./components/SearchBar"));
const CartView = lazy(() => import("./components/CartView"));

export default function App() {
  const [loading, setLoading] = useState(true);
  const [itemsCount, setItemsCount] = useState(0);
  const [cartCount, setCartCount] = useState(0);
  const [showCart, setShowCart] = useState(false);
  const [showOrderPopup, setShowOrderPopup] = useState(false);
  const [orderList, setOrderList] = useState([]);
  const [mobileInput, setMobileInput] = useState("");
  const [showMobilePopup, setShowMobilePopup] = useState(false);
  const [selectedOrderKey, setSelectedOrderKey] = useState(null);

  const loadData = async (forceRefresh = false) => {
    console.log("loadData called, refresh:", forceRefresh);
    const { items } = await loadAndCacheAllJson({ forceRefresh });
    setItemsCount(items.length);
    setLoading(false);
  };

  const updateCartCount = async () => {
    setCartCount(await getCartCount());
  };

  useEffect(() => {
    loadData();
    updateCartCount();
    window.addEventListener("cartUpdated", updateCartCount);
    return () => window.removeEventListener("cartUpdated", updateCartCount);
  }, []);

  const handleAddOrder = async () => {
    console.log("Add Order clicked");
    await clearCart();
    setShowCart(false);
    setSelectedOrderKey(null);
    setMobileInput("");
    alert("🆕 Started a new order. Cart is cleared.");
  };

  const handleEditOrder = async () => {
    console.log("Edit order clicked");
    const allOrders = await getAllOrders();
    const orderArray = Object.entries(allOrders).map(([key, data]) => ({
      key,
      total: calculateTotal(data.cart),
      createdAt: data.createdAt || "",
    }));
    setOrderList(sortOrdersByDate(orderArray).slice(0, 5));
    setShowOrderPopup(true);
  };

  const handleOrderSelect = async (orderKey) => {
    console.log("Order selected:", orderKey);
    const allOrders = await getAllOrders();
    const selectedOrder = allOrders[orderKey];
    if (selectedOrder) {
      await localforage.setItem("cart", {
        ...selectedOrder.cart,
        _orderInfo: { orderKey, mobile: selectedOrder.mobile || "" },
      });
      window.dispatchEvent(new Event("cartUpdated"));
    }
    setSelectedOrderKey(orderKey);
    setShowOrderPopup(false);
    setShowCart(true);
  };

  if (loading) return <div className="p-4">⏳ Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex justify-between p-4">
        <div className="flex gap-2">
          <button onClick={handleAddOrder}>➕ Add Order</button>
          <button onClick={handleEditOrder}>✏️ Edit Order</button>
        </div>
        <div className="flex gap-2 relative">
          <button
            onClick={() => {
              console.log("Cart button clicked");
              if (!mobileInput) setShowMobilePopup(true);
              else setShowCart(true);
            }}
          >
            🛒 Cart {cartCount > 0 && <span>{cartCount}</span>}
          </button>
          <button onClick={() => loadData(true)}>🔄 Refresh</button>
        </div>
      </div>

      {showOrderPopup && (
        <OrderPopup
          orders={orderList}
          onSelect={handleOrderSelect}
          onClose={() => setShowOrderPopup(false)}
        />
      )}

      {showMobilePopup && (
        <MobilePopup
          onConfirm={(num) => {
            setMobileInput(num);
            setShowMobilePopup(false);
            setShowCart(true);
          }}
          onClose={() => setShowMobilePopup(false)}
        />
      )}

      <Suspense fallback={<div>Loading...</div>}>
        {showCart ? (
          <CartView orderKey={selectedOrderKey} />
        ) : (
          <SearchBar />
        )}
      </Suspense>

      <p className="text-sm text-gray-500 text-right p-2">
        Loaded items: {itemsCount}
      </p>
    </div>
  );
}
