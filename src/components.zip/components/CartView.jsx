// src/components/CartView.jsx
import { useEffect, useState } from "react";
import localforage from "localforage";
import {
  calculateTotal,
  saveOrder,
  clearCart
} from "../utils/orderUtils";

export default function CartView({ orderKey }) {
  const [cart, setCart] = useState({});
  const [total, setTotal] = useState(0);
  const [mobile, setMobile] = useState("");

  useEffect(() => {
    const loadCart = async () => {
      const storedCart = (await localforage.getItem("cart")) || {};
      setCart(storedCart);
      setTotal(calculateTotal(storedCart));
      if (storedCart._orderInfo?.mobile) {
        setMobile(storedCart._orderInfo.mobile);
      }
    };
    loadCart();
  }, []);

  const handleQuantityChange = async (id, qty) => {
    const updatedCart = {
      ...cart,
      [id]: { ...cart[id], quantity: qty }
    };
    setCart(updatedCart);
    setTotal(calculateTotal(updatedCart));
    await localforage.setItem("cart", updatedCart);
    window.dispatchEvent(new Event("cartUpdated"));
    console.log(`Quantity changed for item ${id}: ${qty}`);
  };

  const handleSaveOrder = async () => {
    if (!mobile) {
      alert("Please enter mobile number before saving");
      return;
    }
    const now = new Date();
    const orderData = {
      cart: cart,
      mobile,
      createdAt: now.toISOString(),
    };
    const key = orderKey || now.getTime().toString();
    await saveOrder(key, orderData);
    console.log("Order saved:", key, orderData);
    alert(`✅ Order saved successfully (${key})`);
    await clearCart();
    setCart({});
    setTotal(0);
  };

  const handleSendWhatsApp = () => {
    if (!mobile) {
      alert("Please enter mobile number before sending");
      return;
    }
    const message = Object.values(cart)
      .filter(item => item && item.name)
      .map(item => `${item.name} - ₹${item.finalPrice} × ${item.quantity}`)
      .join("\n");
    const waLink = `https://wa.me/91${mobile}?text=${encodeURIComponent(message)}`;
    console.log("Opening WhatsApp:", waLink);
    window.open(waLink, "_blank");
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-bold">🛒 Your Cart</h2>

      <div>
        <label className="block mb-1">Mobile Number:</label>
        <input
          type="text"
          value={mobile}
          onChange={(e) => setMobile(e.target.value.replace(/\D/g, ""))}
          placeholder="10-digit number"
          className="border px-2 py-1 rounded w-full"
        />
      </div>

      <div className="space-y-2">
        {Object.entries(cart)
          .filter(([key]) => key !== "_orderInfo")
          .map(([id, item]) => (
            <div key={id} className="flex justify-between items-center border p-2 rounded">
              <span>{item.name}</span>
              <input
                type="number"
                value={item.quantity}
                onChange={(e) => handleQuantityChange(id, parseInt(e.target.value))}
                className="w-16 border rounded px-1"
                min="1"
              />
            </div>
          ))}
      </div>

      <div className="font-bold">Total: ₹{total.toFixed(2)}</div>

      <div className="flex gap-2">
        <button
          onClick={handleSaveOrder}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          💾 Save Order
        </button>
        <button
          onClick={handleSendWhatsApp}
          className="px-4 py-2 bg-green-600 text-white rounded"
        >
          📲 Send via WhatsApp
        </button>
      </div>
    </div>
  );
}
