// src/components/OrderPopup.jsx
import Modal from "./Modal";

export default function OrderPopup({ orders, onSelect, onClose }) {
  return (
    <Modal title="Select Order" onClose={onClose}>
      <div className="space-y-2">
        {orders.length === 0 ? (
          <p className="text-center text-gray-500">No orders found</p>
        ) : (
          orders.map((o) => (
            <div
              key={o.key}
              className="flex justify-between p-3 border rounded cursor-pointer hover:bg-gray-100"
              onClick={() => {
                console.log("Order selected:", o.key);
                onSelect(o.key);
              }}
            >
              <span>{o.key}</span>
              <span className="text-green-700">₹{o.total.toFixed(2)}</span>
            </div>
          ))
        )}
      </div>
    </Modal>
  );
}
