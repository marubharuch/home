// src/utils/orderUtils.js
import localforage from "localforage";

export async function getCartCount() {
  const cart = (await localforage.getItem("cart")) || {};
  return Object.values(cart).reduce(
    (sum, item) => sum + (item.quantity || 0),
    0
  );
}

export async function clearCart() {
  await localforage.setItem("cart", {});
  window.dispatchEvent(new Event("cartUpdated"));
}

export async function getAllOrders() {
  let orders = await localforage.getItem("orders");
  if (!orders || typeof orders !== "object") {
    orders = {};
    await localforage.setItem("orders", {});
  }
  return orders;
}

export function sortOrdersByDate(orderArray) {
  const parseTS = (d) => {
    const t = Date.parse(d);
    return isNaN(t) ? 0 : t;
  };
  return orderArray.sort((a, b) => parseTS(b.createdAt) - parseTS(a.createdAt));
}

export function calculateTotal(cart) {
  return Object.values(cart || {}).reduce(
    (sum, item) =>
      sum + ((parseFloat(item.finalPrice) || 0) * (item.quantity || 0)),
    0
  );
}

export async function saveOrder(orderKey, orderData) {
  const allOrders = await getAllOrders();
  await localforage.setItem("orders", { ...allOrders, [orderKey]: orderData });
}
